"use client"

import * as React from "react"
import { 
  TrendingUp, 
  Activity, 
  Flame, 
  Target,
  ArrowRight
} from "lucide-react"
import { 
  Bar, 
  BarChart, 
  CartesianGrid, 
  XAxis,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  Cell,
  Pie,
  PieChart,
} from "recharts"
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { useUser, useFirestore } from "@/firebase"
import { doc, getDoc } from "firebase/firestore"
import { Loader2 } from "lucide-react"
import Link from "next/link"

interface UserProfile {
  firstName: string
  lastName: string
  weight: string
  targetWeight: string
  goal: string
  activityLevel: string
}

const emptyCalorieData = [
  { day: "Mon", consumed: 0, goal: 2000 },
  { day: "Tue", consumed: 0, goal: 2000 },
  { day: "Wed", consumed: 0, goal: 2000 },
  { day: "Thu", consumed: 0, goal: 2000 },
  { day: "Fri", consumed: 0, goal: 2000 },
  { day: "Sat", consumed: 0, goal: 2000 },
  { day: "Sun", consumed: 0, goal: 2000 },
]

const emptyMacroData = [
  { name: "Protein", value: 33, color: "hsl(var(--primary))" },
  { name: "Carbs", value: 34, color: "hsl(var(--accent))" },
  { name: "Fats", value: 33, color: "hsl(var(--muted-foreground))" },
]

export default function DashboardPage() {
  const { user } = useUser()
  const firestore = useFirestore()
  const [profile, setProfile] = React.useState<UserProfile | null>(null)
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    if (!user) return
    const fetchProfile = async () => {
      try {
        const docRef = doc(firestore, "users", user.uid)
        const docSnap = await getDoc(docRef)
        if (docSnap.exists()) {
          setProfile(docSnap.data() as UserProfile)
        }
      } catch (err) {
        console.error("Dashboard load error:", err)
      } finally {
        setLoading(false)
      }
    }
    fetchProfile()
  }, [user, firestore])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const displayName = profile?.firstName 
    ? `${profile.firstName} ${profile.lastName}`.trim() 
    : user?.email?.split("@")[0] || "there"

  const currentWeight = profile?.weight ? parseFloat(profile.weight) : null
  const targetWeight = profile?.targetWeight ? parseFloat(profile.targetWeight) : null
  const weightDiff = currentWeight && targetWeight ? (targetWeight - currentWeight).toFixed(1) : null
  const isProfileComplete = profile?.firstName && profile?.weight

  return (
    <div className="flex flex-col gap-8 py-6 max-w-7xl mx-auto w-full">
      
      {/* Welcome */}
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-bold font-headline">Welcome back, {displayName}! 👋</h1>
        <p className="text-muted-foreground">
          {isProfileComplete 
            ? `Your goal: ${profile?.goal || "Not set"} ${targetWeight ? `→ ${targetWeight} kg` : ""}`
            : "Complete your profile to get personalized insights!"}
        </p>
        {!isProfileComplete && (
          <Link href="/profile">
            <Button className="mt-2 rounded-full w-fit" size="sm">
              Setup Profile <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-sm border-none bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Daily Calories</CardTitle>
            <Flame className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0 / 2,000</div>
            <Progress value={0} className="mt-2 h-2" />
            <p className="text-xs text-muted-foreground mt-2">Start logging your meals!</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-none bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Activity</CardTitle>
            <Activity className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0 kcal</div>
            <p className="text-xs text-muted-foreground mt-1">No activity logged today</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-none bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Weight</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {currentWeight ? `${currentWeight} kg` : "Not set"}
            </div>
            {weightDiff && (
              <p className="text-xs text-muted-foreground mt-1">
                {parseFloat(weightDiff) > 0 
                  ? `${weightDiff} kg to gain` 
                  : `${Math.abs(parseFloat(weightDiff))} kg to lose`}
              </p>
            )}
            {!currentWeight && (
              <p className="text-xs text-muted-foreground mt-1">Set in Profile</p>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm border-none bg-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Streak</CardTitle>
            <Target className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0 Days</div>
            <p className="text-xs text-muted-foreground mt-1">Start logging to build streak!</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-bold font-headline">Weekly Calorie Intake</CardTitle>
            <CardDescription>Start logging meals to see your progress</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px] w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={emptyCalorieData}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.1} />
                <XAxis dataKey="day" axisLine={false} tickLine={false} tickMargin={10} fontSize={12} />
                <Tooltip
                  cursor={{ fill: 'hsl(var(--accent))', opacity: 0.1 }}
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="consumed" radius={[4, 4, 0, 0]}>
                  {emptyCalorieData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.consumed > entry.goal ? 'hsl(var(--destructive))' : 'hsl(var(--primary))'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-bold font-headline">Nutrient Balance</CardTitle>
            <CardDescription>Today's macronutrient split</CardDescription>
          </CardHeader>
          <CardContent className="h-[250px] w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={emptyMacroData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {emptyMacroData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
          <CardFooter className="flex-col gap-2 pb-6">
            <div className="flex w-full items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-primary" />
                <span>Protein</span>
              </div>
              <span className="font-bold">0g</span>
            </div>
            <div className="flex w-full items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-accent" />
                <span>Carbs</span>
              </div>
              <span className="font-bold">0g</span>
            </div>
            <div className="flex w-full items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full bg-muted-foreground" />
                <span>Fats</span>
              </div>
              <span className="font-bold">0g</span>
            </div>
          </CardFooter>
        </Card>
      </div>

      {/* Weight Journey */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="col-span-1 md:col-span-2 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-bold font-headline">Weight Journey</CardTitle>
            <CardDescription>
              {targetWeight 
                ? `Progress towards your ${targetWeight}kg target` 
                : "Set your target weight in Profile"}
            </CardDescription>
          </CardHeader>
          <CardContent className="h-[300px] flex items-center justify-center">
            {currentWeight ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={[{ date: "Today", weight: currentWeight }]}>
                  <CartesianGrid vertical={false} strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tickMargin={10} fontSize={12} />
                  <Tooltip contentStyle={{ borderRadius: '8px', border: 'none' }} />
                  <Line
                    type="monotone"
                    dataKey="weight"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-muted-foreground">
                <p className="text-sm">No weight data yet</p>
                <Link href="/profile">
                  <Button variant="link" size="sm">Set your weight in Profile</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-primary/5">
          <CardHeader>
            <CardTitle className="text-lg font-bold font-headline flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-primary" />
              AI Insights
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isProfileComplete ? (
              <>
                <div className="p-3 rounded-lg bg-white shadow-sm border border-primary/10">
                  <p className="text-sm font-medium">Profile Complete! 🎉</p>
                  <p className="text-xs text-muted-foreground mt-1">Start logging meals and activities to get personalized AI insights.</p>
                </div>
                <div className="p-3 rounded-lg bg-white shadow-sm border border-primary/10">
                  <p className="text-sm font-medium">Goal: {profile?.goal}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {targetWeight && currentWeight
                      ? `You need to ${parseFloat(weightDiff || "0") > 0 ? "gain" : "lose"} ${Math.abs(parseFloat(weightDiff || "0"))} kg to reach your goal.`
                      : "Set your target weight to track progress."}
                  </p>
                </div>
              </>
            ) : (
              <div className="p-3 rounded-lg bg-white shadow-sm border border-primary/10">
                <p className="text-sm font-medium">Setup your profile!</p>
                <p className="text-xs text-muted-foreground mt-1">Complete your profile to unlock personalized AI insights and recommendations.</p>
              </div>
            )}
            <Link href="/insights">
              <Button className="w-full rounded-full group" variant="ghost">
                View Detailed Report <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function Lightbulb(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .5 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" />
      <path d="M9 18h6" />
      <path d="M10 22h4" />
    </svg>
  )
}